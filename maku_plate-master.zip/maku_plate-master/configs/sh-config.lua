PLATE_ITEM = 'vehicle_plate'
EMPTY_PLATE = '        '
ALLOWED_TYPES = {
    ['automobile'] = true,
    ['bike'] = true,
    ['boat'] = false,
    ['heli'] = false,
    ['plane'] = false,
    ['submarine'] = false,
    ['trailer'] = true,
    ['train'] = false
}
TARGET_TAKE_OFF = 'Take off plate'
CLOSEST_VEHICLE_RANGE = 5.0
